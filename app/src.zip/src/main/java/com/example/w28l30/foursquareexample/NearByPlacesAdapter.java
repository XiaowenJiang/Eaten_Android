package com.example.w28l30.foursquareexample;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by W28L30 on 15/11/1.
 */
public class NearByPlacesAdapter extends BaseAdapter {
    ArrayList<FoursquareVenue> mNearByList;
    private Context mContext;

    public NearByPlacesAdapter(Context context, ArrayList<FoursquareVenue> objects) {
        mContext = context;
        mNearByList = objects;
    }

    @Override
    public int getCount() {
        return mNearByList.size();
    }

    @Override
    public FoursquareVenue getItem(int position) {
        return mNearByList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = convertView;
        ViewHolder viewHolder;
        if (convertView == null) {
            LayoutInflater li = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v = li.inflate(R.layout.item_list_nearby, null, true);
            viewHolder = new ViewHolder(v);
            v.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) v.getTag();
        }
        viewHolder.tv_address.setText(mNearByList.get(position).getCity());
        viewHolder.tv_name.setText(mNearByList.get(position).getName());

        return v;
    }

    class ViewHolder {
        TextView tv_address;
        TextView tv_name;

        public ViewHolder(View view) {
            tv_address = (TextView) view.findViewById(R.id.tv_address);
            tv_name = (TextView) view.findViewById(R.id.tv_name);
        }
    }
}

package com.example.w28l30.foursquareexample;

import com.orm.SugarRecord;

/**
 * Created by W28L30 on 15/11/1.
 */
public class Dinner extends SugarRecord<Dinner> {
    public String restaurant;
    public String address;

    public Dinner() {

    }

    public Dinner(String restaurant, String address) {
        this.restaurant = restaurant;
        this.address = address;
    }

    public String getAddress() {
        return address;
    }

    public String getRestaurant() {
        return restaurant;
    }
}

package com.example.w28l30.foursquareexample;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.TypedValue;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.baoyz.swipemenulistview.SwipeMenu;
import com.baoyz.swipemenulistview.SwipeMenuCreator;
import com.baoyz.swipemenulistview.SwipeMenuItem;
import com.baoyz.swipemenulistview.SwipeMenuListView;
import com.fourmob.datetimepicker.date.DatePickerDialog;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.UiSettings;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.sleepbot.datetimepicker.time.RadialPickerLayout;
import com.sleepbot.datetimepicker.time.TimePickerDialog;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;

import de.greenrobot.event.EventBus;

public class MapsActivity extends FragmentActivity implements DatePickerDialog.OnDateSetListener, TimePickerDialog.OnTimeSetListener {

    private GoogleMap mMap; // Might be null if Google Play services APK is not available.

    private EventBus bus = EventBus.getDefault();


    // the foursquare client_id and the client_secret
    private final String CLIENT_ID = "U3VRM3SJ1S3MXCZL0EM0GDFUHK0W2GOTUJVWBIDH3QRVOTHS";
    private final String CLIENT_SECRET = "AFRE3BAJT40TIAJQGG0GDVJUYUG1KVDMAJM2SXJTXB2KYKA3";
    private static String TAG = MapsActivity.class.getSimpleName();

    private NearByPlacesAdapter mAdapter;
    private SwipeMenuListView mListView;
    private ArrayList<FoursquareVenue> mVenueList;

    public static final String DATEPICKER_TAG = "datepicker";
    public static final String TIMEPICKER_TAG = "timepicker";
    final Calendar calendar = Calendar.getInstance();
    final DatePickerDialog datePickerDialog = DatePickerDialog.newInstance(this, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
    final TimePickerDialog timePickerDialog = TimePickerDialog.newInstance(this, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), false, false);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        bus.register(this);
        new UpdateLatLngService(this);

        setUpMapIfNeeded();

        mListView = (SwipeMenuListView) findViewById(R.id.listView);
//        mAdapter = new AppAdapter();
//        mListView.setAdapter(mAdapter);

        if (savedInstanceState != null) {
            DatePickerDialog dpd = (DatePickerDialog) getSupportFragmentManager().findFragmentByTag(DATEPICKER_TAG);
            if (dpd != null) {
                dpd.setOnDateSetListener(this);
            }

            TimePickerDialog tpd = (TimePickerDialog) getSupportFragmentManager().findFragmentByTag(TIMEPICKER_TAG);
            if (tpd != null) {
                tpd.setOnTimeSetListener(this);
            }
        }

    }


    public void onDateSet(DatePickerDialog datePickerDialog, int year, int month, int day) {
        Toast.makeText(MapsActivity.this, "new date:" + year + "-" + month + "-" + day, Toast.LENGTH_LONG).show();
    }

    public void onTimeSet(RadialPickerLayout view, int hourOfDay, int minute) {
        Toast.makeText(MapsActivity.this, "new time:" + hourOfDay + "-" + minute, Toast.LENGTH_LONG).show();
    }


    @Override
    protected void onDestroy() {
        bus.unregister(this);
        super.onDestroy();
    }

    public void onEvent(MessageEvent event) {
        LatLng currentLatLng = event.getLatLng();
        double currentLatitude = currentLatLng.latitude;
        double currentLongitude = currentLatLng.longitude;

        mMap.moveCamera(CameraUpdateFactory.newLatLng(currentLatLng));
        mMap.animateCamera(CameraUpdateFactory.zoomTo(15));

        String urlJsonObj = "https://api.foursquare.com/v2/venues/search?client_id="
                + CLIENT_ID
                + "&client_secret="
                + CLIENT_SECRET
                + "&v=20150815&ll="
                + String.valueOf(currentLatitude)
                + ","
                + String.valueOf(currentLongitude);

        makeJsonObjectRequest(urlJsonObj);

    }

    private void addMarker(ArrayList<FoursquareVenue> list) {
        for (int i = 0; i < list.size(); i++) {
            MarkerOptions marker = new MarkerOptions().position(
                    new LatLng(list.get(i).getLatitude(), list.get(i).getlongitude())).title(list.get(i).getName());

            // Changing marker icon
            marker.icon(BitmapDescriptorFactory
                    .defaultMarker(BitmapDescriptorFactory.HUE_GREEN));

            // adding marker
            mMap.addMarker(marker);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.activity_maps_actions, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_show_create_dinners:
                showCreatedDinners();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void showCreatedDinners() {
        Intent i = new Intent(MapsActivity.this, ShowCreatedDinnerListActivity.class);
        startActivity(i);
    }

    @Override
    protected void onResume() {
        super.onResume();
        setUpMapIfNeeded();
    }

    /**
     * Sets up the map if it is possible to do so (i.e., the Google Play services APK is correctly
     * installed) and the map has not already been instantiated.. This will ensure that we only ever
     * call {@link #setUpMap()} once when {@link #mMap} is not null.
     * <p/>
     * If it isn't installed {@link SupportMapFragment} (and
     * {@link com.google.android.gms.maps.MapView MapView}) will show a prompt for the user to
     * install/update the Google Play services APK on their device.
     * <p/>
     * A user can return to this FragmentActivity after following the prompt and correctly
     * installing/updating/enabling the Google Play services. Since the FragmentActivity may not
     * have been completely destroyed during this process (it is likely that it would only be
     * stopped or paused), {@link #onCreate(Bundle)} may not be called again so we should call this
     * method in {@link #onResume()} to guarantee that it will be called.
     */
    private void setUpMapIfNeeded() {
        // Do a null check to confirm that we have not already instantiated the map.
        if (mMap == null) {
            // Try to obtain the map from the SupportMapFragment.
            mMap = ((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.googleMap))
                    .getMap();
            mMap.setMyLocationEnabled(true);
            UiSettings uiSettings = mMap.getUiSettings();
            uiSettings.setCompassEnabled(true);
            uiSettings.setZoomControlsEnabled(true);
            // Check if we were successful in obtaining the map.
            if (mMap != null) {
                setUpMap();
            }
        }
    }

    /**
     * This is where we can add markers or lines, add listeners or move the camera. In this case, we
     * just add a marker near Africa.
     * <p/>
     * This should only be called once and when we are sure that {@link #mMap} is not null.
     */
    private void setUpMap() {
        mMap.addMarker(new MarkerOptions().position(new LatLng(0, 0)).title("Marker"));
    }

    private void makeJsonObjectRequest(String urlJsonObj) {


        JsonObjectRequest jsonObjReq = new JsonObjectRequest(
                urlJsonObj, new Response.Listener<JSONObject>() {

            @Override
            public void onResponse(JSONObject response) {
                try {
                    ArrayList<FoursquareVenue> venuesList = new ArrayList<FoursquareVenue>();
//                    response = response.trim();
                    // make an jsonObject in order to parse the response
                    JSONObject jsonObject = response;

                    // make an jsonObject in order to parse the response
                    if (jsonObject.has("response")) {
                        if (jsonObject.getJSONObject("response").has("venues")) {
                            JSONArray jsonArray = jsonObject.getJSONObject("response").getJSONArray("venues");

                            for (int i = 0; i < jsonArray.length(); i++) {
                                FoursquareVenue poi = new FoursquareVenue();
                                if (jsonArray.getJSONObject(i).has("name")) {
                                    poi.setName(jsonArray.getJSONObject(i).getString("name"));

                                    if (jsonArray.getJSONObject(i).has("location")) {
                                        if (jsonArray.getJSONObject(i).getJSONObject("location").has("address")) {
                                            if (jsonArray.getJSONObject(i)
                                                    .getJSONObject("location")
                                                    .has("lat")) {
                                                poi.setLatitude(jsonArray
                                                        .getJSONObject(i)
                                                        .getJSONObject("location")
                                                        .getString("lat"));
                                            }
                                            if (jsonArray.getJSONObject(i)
                                                    .getJSONObject("location")
                                                    .has("lng")) {
                                                poi.setlongitude(jsonArray
                                                        .getJSONObject(i)
                                                        .getJSONObject("location")
                                                        .getString("lng"));
                                            }
                                            if (jsonArray.getJSONObject(i).getJSONObject("location").has("city")) {
                                                poi.setCity(jsonArray.getJSONObject(i).getJSONObject("location").getString("city"));
                                            }
                                            if (jsonArray.getJSONObject(i).has("categories")) {
                                                if (jsonArray.getJSONObject(i).getJSONArray("categories").length() > 0) {
                                                    if (jsonArray.getJSONObject(i).getJSONArray("categories").getJSONObject(0).has("icon")) {
                                                        poi.setCategory(jsonArray.getJSONObject(i).getJSONArray("categories").getJSONObject(0).getString("name"));
                                                    }
                                                }
                                            }
                                            venuesList.add(poi);
                                        }
                                    }
                                }
                            }

                            SwipeMenuCreator creator = new SwipeMenuCreator() {
                                @Override
                                public void create(SwipeMenu swipeMenu) {
                                    SwipeMenuItem openItem = new SwipeMenuItem(
                                            getApplicationContext());
                                    // set item background
                                    openItem.setBackground(new ColorDrawable(Color.rgb(0xC9, 0xC9,
                                            0xCE)));
                                    // set item width
                                    openItem.setWidth(dp2px(90));
                                    // set item title
                                    openItem.setTitle("Add");
                                    // set item title fontsize
                                    openItem.setTitleSize(18);
                                    // set item title font color
                                    openItem.setTitleColor(Color.WHITE);
                                    // add to menu
                                    swipeMenu.addMenuItem(openItem);

                                    // create "delete" item
                                    SwipeMenuItem deleteItem = new SwipeMenuItem(
                                            getApplicationContext());
                                    // set item background
                                    deleteItem.setBackground(new ColorDrawable(Color.rgb(0xF9,
                                            0x3F, 0x25)));
                                    // set item width
                                    deleteItem.setWidth(dp2px(90));
                                    // set a icon
//                deleteItem.setIcon(R.drawable.ic_delete);
                                    // add to menu
                                    swipeMenu.addMenuItem(deleteItem);
                                }
                            };


                            if (venuesList != null) {
                                mVenueList = venuesList;
                                mAdapter = new NearByPlacesAdapter(getBaseContext(), mVenueList);
                                mListView.setAdapter(mAdapter);
                                mListView.setMenuCreator(creator);

                                mListView.setOnMenuItemClickListener(new SwipeMenuListView.OnMenuItemClickListener() {
                                    @Override
                                    public boolean onMenuItemClick(int position, SwipeMenu menu, int index) {
                                        FoursquareVenue item = mVenueList.get(position);
                                        switch (index) {
                                            case 0:
                                                // open
                                                add(item);
                                                break;
                                            case 1:
                                                // delete
                                                datePickerDialog.setYearRange(1985, 2028);
                                                datePickerDialog.show(getSupportFragmentManager(), DATEPICKER_TAG);
                                                break;
                                        }
                                        return false;
                                    }
                                });
                                addMarker(venuesList);
                            }
                        }
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
            }
        });

        Volley.newRequestQueue(this).add(jsonObjReq);
    }


    private int dp2px(int dp) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp,
                getResources().getDisplayMetrics());
    }

    private void add(FoursquareVenue item) {
        String restaurant = item.getName();
        String address = item.getCity();

        Dinner dinner = new Dinner(restaurant, address);
        dinner.save();
    }

}

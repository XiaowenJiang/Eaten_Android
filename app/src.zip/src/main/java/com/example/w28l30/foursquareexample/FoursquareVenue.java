package com.example.w28l30.foursquareexample;

public class FoursquareVenue {
	private String name;
	private String city;

	private String category;
	private String longitude;
	private String latitude;

	public FoursquareVenue() {
		this.name = "";
		this.city = "";
		this.setCategory("");
	}

	public String getCity() {
		if (city.length() > 0) {
			return city;
		}
		return city;
	}

	public void setCity(String city) {
		if (city != null) {
			this.city = city.replaceAll("\\(", "").replaceAll("\\)", "");
			;
		}
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public void setlongitude(String longitude) {
		this.longitude = longitude;
	}

	public double getLatitude() {
		return Double.parseDouble(latitude);
	}

	public double getlongitude() {
		return Double.parseDouble(longitude);
	}
}
